#include <ros/ros.h>
#include <geometry_msgs/Twist.h>

#include "rosrt_rt1/Rt1Sensor.h"

#include <iostream>
#include <stdio.h>
#include <math.h>
#include <vector>
#include <string>
#include <eigen3/Eigen/Dense>
#include <eigen3/Eigen/Core>

using namespace std;

class rt_move{
public:
    typedef struct {
        double accel_linear_x, accel_linear_y, accel_linear_z;
        double accel_angular_x, accel_angular_y, accel_angular_z;

        double handle_force_x, handle_force_l, handle_force_r;
        double handle_torque_x, handle_torque_y, handle_torque_z;

        double velocity_linear_x, velocity_linear_y, velocity_linear_z;
        double velocity_angular_x, velocity_angular_y, velocity_angular_z;
    }RT1sensor;

    RT1sensor sensor;
    rt_move();
    ~rt_move();
    void handleCallback(const rosrt_rt1::Rt1Sensor::ConstPtr& rtsensor);
    void setMoveVector(float linear_x, float angular_z, int cnt);
    void timerCallback(const ros::TimerEvent&);
   
private:
    ros::Publisher twist_pub;
    ros::Subscriber handle_sub;
    ros::Timer timer;
    ros::NodeHandle nh;
};
   
rt_move::rt_move(){
    twist_pub = nh.advertise<geometry_msgs::Twist>("/cmd_vel", 1000);
    handle_sub = nh.subscribe<rosrt_rt1::Rt1Sensor>("/rosrt_rt1", 1, &rt_move::handleCallback, this);
    
    timer = nh.createTimer(ros::Duration(0.1), &rt_move::timerCallback, this);
   
    geometry_msgs::Twist twist;
    twist.linear.x = 0.0;
    twist.linear.y = 0.0;
    twist.linear.z = 0.0;
    twist.angular.x = 0.0;
    twist.angular.y = 0.0;
    twist.angular.z = 0.0;
    twist_pub.publish(twist);
}
   
rt_move::~rt_move(){
}
  
void rt_move::handleCallback(const rosrt_rt1::Rt1Sensor::ConstPtr& rtsensor){
    sensor.handle_force_x = rtsensor->handle.force.x; 
    sensor.handle_force_l = rtsensor->handle.force.y;
    sensor.handle_force_r = rtsensor->handle.force.z;
    sensor.handle_torque_z = rtsensor->handle.torque.z;
}
   
void rt_move::timerCallback(const ros::TimerEvent&){
    double lin_x=0, ang_z=0;

    if(abs(sensor.handle_force_l) > 1.5 && abs(sensor.handle_force_r) > 1.5){
       lin_x = sensor.handle_force_x;
       ang_z = sensor.handle_torque_z;   //sensor.handle_force_r - sensor.handle_force_l; 
       setMoveVector( lin_x, ang_z, 1); 
    }
    
    cout << lin_x <<" : "<< ang_z << endl;
}
   
void rt_move::setMoveVector(float linear_x, float angular_z, int cnt){
    int i;
    geometry_msgs::Twist twist;
    ros::Rate loop_rate(10);
   
    for(i = 0;i < cnt; i++){
        twist.linear.x = linear_x/40;
        twist.angular.z = angular_z/200;
        twist_pub.publish(twist);
        loop_rate.sleep();
    }
}
   
int main(int argc, char **argv){
    ros::init(argc, argv, "rt1_move");
   
    rt_move rt_move;
   
    ros::spin();
    return 0;
}
         