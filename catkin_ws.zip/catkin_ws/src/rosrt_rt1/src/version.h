/***************************************************************************//**
 * @file		version.h
 * @brief		�o�[�W�����ԍ�
 *
 * @author		�ЎR�M��<katayama.takahiro@rtworks.co.jp>
 * @par			Copyright
 * 2012-2014	RT.Works co., ltd. All rights reserved.
 *
 *****************************************************************************/

#ifndef _INCLUDE_VERSION_H_
#define _INCLUDE_VERSION_H_

#define VERSION_NUMBER "7.0.2"

#endif /* _INCLUDE_VERSION_H_ */
